import React, { useState } from "react";
import Search from "./search.jsx";
import Catalog from "./catalog.jsx";

const CatalogApp = ({ products, onAddToCart }) => {
    const [filteredProducts, setFilteredProducts] = useState(products);

    // Функция фильтрации продуктов
    const handleSearch = (searchValue, searchType) => {
        if (!searchValue) {
            setFilteredProducts(products); // Показываем все продукты, если поиск пустой
            return;
        }

        const filtered = products.filter((product) =>
            searchType === "exact"
                ? product.name.toLowerCase() === searchValue.toLowerCase()
                : product.name.toLowerCase().includes(searchValue.toLowerCase())
        );

        setFilteredProducts(filtered);
    };

    return (
        <div>
            <header>
                <Search onSearch={handleSearch} />
            </header>
            <main>
                <Catalog products={filteredProducts} onAddToCart={onAddToCart} />
            </main>
        </div>
    );
};

export default CatalogApp;
import React from "react";
import { useNavigate } from "react-router-dom"; // Импортируем useNavigate
import "./styles/header.css";

const Header = () => {
    const navigate = useNavigate(); // Инициализируем хук useNavigate

    const goHome = () => navigate('/');
    const goCatalog = () => navigate('/catalogPage');
    const goCart = () => navigate('/cart');

    return (
        <div>
            <header className='header'>
                <h4>BOOKS</h4>
                <h4 className='menu' onClick={goHome}>Главная</h4>
                <h4 className='menu' onClick={goCatalog}>Каталог</h4>
                <h4 className='menu' onClick={goCart}>Корзина</h4>
            </header>
        </div>
    );
}

export default Header;
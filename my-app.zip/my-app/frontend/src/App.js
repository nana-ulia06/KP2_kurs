import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './header';
import Footer from './footer';
import Home from './home';
import CatalogApp from './catalogPage';
import BookPage from './bookPage';
import products from './products';
import Cart from './cart';
import { useDispatch } from 'react-redux';
import { addToCart } from './actions';
import OrderForm from './orderForm';

function App() {
  const dispatch = useDispatch();

  const handleAddToCart = (book) => {
    dispatch(addToCart(book));  // Использование dispatch для добавления товара в корзину
  };

  return (
    <div>
      <Router>
        <div>
          <Header />
        </div>
        <Routes>
          <Route path='/' element={<Home />}/>
          <Route path='/catalogPage' element={<CatalogApp products={products} onAddToCart={handleAddToCart}/>} />
          <Route path='/bookPage/:id' element={<BookPage products = {products} onAddToCart={handleAddToCart}/>}/>
          <Route path='/cart' element={<Cart />}/>
          <Route path='/orderForm' element={<OrderForm />} />
        </Routes>
        <div>
          <Footer />
        </div>
      </Router>
    </div>
  )
}

export default App;
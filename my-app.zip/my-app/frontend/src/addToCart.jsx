import React from "react";
import "./styles/addToCart.css";

const AddToCartButton = ({ onClick, book }) => {
    return (
        <button
            className="add-to-cart"
            onClick={(e) => {
                e.stopPropagation();
                onClick(book);
            }}>
            В корзину
        </button>
    );
}

export default AddToCartButton;
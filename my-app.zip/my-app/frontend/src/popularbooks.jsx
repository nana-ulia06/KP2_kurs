import React from "react";
import "./styles/popularBooks.css";

const PopularBooks = ({popular}) => {
    return (
        <div className="popularBooks">
            {popular.map((book, index) => {
                return (
                    <div key={index} className="book-card">
                        <img src={book.image} alt={book.title} className="popularImage"/>
                        <div>
                            <p><h2 className="popularTitle">{book.title}</h2></p>
                            <p><h3 className="popularAuthor">{book.author}</h3></p>
                            <p><h3 className="popularPrice">{book.price} бел. руб.</h3></p>
                        </div>
                    </div>
                )
            })}
        </div>
    )
}
export default PopularBooks;
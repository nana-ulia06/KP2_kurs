import { createStore } from 'redux';
import rootReducer from './combineReducers';

// Создаем store
const store = createStore(rootReducer);

export default store;
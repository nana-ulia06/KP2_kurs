import React from "react";
import BooksCarousel from './slider';
import PopularBooks from "./popularbooks";
  
  const books = [
    {
      id: 1,
      title: 'Знакомство с убийцей',
      author: 'Но Хёду',
      image: 'https://cv2.litres.ru/pub/c/cover_330/70740220.webp',
      cost: 34
    },
    {
      id: 2,
      title: 'God of Fury',
      author: 'Рина Кент',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoNr9nokjWbzZ3hTlYVX36wsitRKRchWfnWloNCS1Sbnhy5iDO',
      cost: 30
    },
    {
      id: 3,
      title: 'Три года в аду. Как Светлана Богачева украла мою жизнь',
      author: 'Таня Щукина',
      image: 'https://cv0.litres.ru/pub/c/cover_415/70731301.webp',
      cost: 27
    },
    {
      id: 4,
      title: 'Лиллехейм. Волчий ветер',
      author: 'Николай Ободников',
      image: 'https://s1.livelib.ru/boocover/1008326869/200x305/67be/boocover.jpg',
      cost: 40
    },
    {
      id: 5,
      title: 'Убийство в городе без имени',
      author: 'Кэйго Хигасино',
      image: 'https://s1.livelib.ru/boocover/1008485845/200x305/b3d6/boocover.jpg',
      cost: 20
    },
    {
      id: 6,
      title: 'Знакомство с убийцей',
      author: 'Но Хёду',
      image: 'https://cv2.litres.ru/pub/c/cover_330/70740220.webp',
      cost: 34
    },
    {
      id: 7,
      title: 'God of Fury',
      author: 'Рина Кент',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoNr9nokjWbzZ3hTlYVX36wsitRKRchWfnWloNCS1Sbnhy5iDO',
      cost: 30
    },
    {
      id: 8,
      title: 'Три года в аду. Как Светлана Богачева украла мою жизнь',
      author: 'Таня Щукина',
      image: 'https://cv0.litres.ru/pub/c/cover_415/70731301.webp',
      cost: 27
    },
    {
      id: 9,
      title: 'Лиллехейм. Волчий ветер',
      author: 'Николай Ободников',
      image: 'https://s1.livelib.ru/boocover/1008326869/200x305/67be/boocover.jpg',
      cost: 40
    },
    {
      id: 10,
      title: 'Убийство в городе без имени',
      author: 'Кэйго Хигасино',
      image: 'https://s1.livelib.ru/boocover/1008485845/200x305/b3d6/boocover.jpg',
      cost: 20
    },
  ];
  const popular = [
    {
        title: 'Холли',
        author: 'Стивен Кинг',
        price: 35,
        image: 'https://avatars.dzeninfra.ru/get-zen_doc/271828/pub_65be3dc3fc375f70f7b496b8_65be479b0c576e32786e5a59/scale_1200'
    },
    {
        title: 'После бури',
        author: 'Фредрик Бакман',
        price: 41,
        image: 'https://avatars.mds.yandex.net/i?id=b75006e54b2329933a2536153989d900_l-5232197-images-thumbs&n=13'
    },
    {
        title: 'Земля Королей. Червовый том',
        author: 'Нечитайло Ф.К.',
        price: 53,
        image: 'https://www.belykrolik.ru/media/catalog/product_images/21737411_1_zemlya-korolej-chervovyij-tom.jpg'
    },
    {
        title: 'Возвращение в таинственный сад',
        author: 'Холли Вебб',
        price: 15,
        image: 'https://www.belykrolik.ru/media/catalog/product_images/20183311_1_vozvraschenie-v-tainstvennyij-sad.jpg'
    },
    {
        title: 'Удивительные истории о бабушках и дедушках',
        author: 'Александр Цыпкин',
        price: 34,
        image: 'https://img.chaconne.ru/img/4082723_936342.jpg'
    }
]

const Home = () => {
    return (
        <div>
            <div>
                <main className='main'>
                <h2 style={{textAlign: 'center'}}>НОВИНКИ</h2>
                <BooksCarousel books={books} />

                <h2 style={{textAlign: 'center'}}>ПОПУЛЯРНЫЕ ТОВАРЫ</h2>
                <PopularBooks popular={popular} />
                </main>
            </div>
        </div>
    )
}

export default Home;
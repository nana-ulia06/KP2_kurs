import React from "react";
import "./styles/footer.css";

const Footer = () => {
    return (
        <div>
            <footer className='footer'>
                <h4>&#169;BOOKS</h4>
                <h4>Дужик У.С.</h4>
                <h4>2 курс, 1 группа</h4>
                <h4>БГТУ</h4>
            </footer>
        </div>
    )
}

export default Footer;